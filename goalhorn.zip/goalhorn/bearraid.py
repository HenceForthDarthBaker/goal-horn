import RPi.GPIO as GPIO, time, os, subprocess

def bear_raid():
    GPIO.setmode (GPIO.BOARD)
    GPIO.setup(7,GPIO.IN)
    subprocess.Popen(["python", '/home/pi/goalhorn/b_raid.py'])
    time.sleep(.5)
    GPIO.setup(7,GPIO.OUT)
    time.sleep(23)
    GPIO.setup(7,GPIO.IN)
    time.sleep(1)
    GPIO.cleanup()