import RPi.GPIO as GPIO, time, os, subprocess

def bear_light():
    GPIO.setmode (GPIO.BOARD)
    GPIO.setup(7,GPIO.IN)
    subprocess.Popen(["python", '/home/pi/goalhorn/beardown.py'])
    time.sleep(.5)
    GPIO.setup(7,GPIO.OUT)
    time.sleep(55)
    GPIO.setup(7,GPIO.IN)
    time.sleep(1)
    GPIO.cleanup()
