import RPi.GPIO as GPIO, time, os, subprocess

def flash_lights():
    GPIO.setmode (GPIO.BOARD)
    GPIO.setup(7,GPIO.IN)
    subprocess.Popen(["python", '/home/pi/goalhorn/goalhorn.py'])
    time.sleep(.5)
    GPIO.setup(7,GPIO.OUT)
    #subprocess.Popen(["python", '/home/pi/goalhorn/goalhorn.py'])
    time.sleep(42)
    GPIO.setup(7,GPIO.IN)
    time.sleep(1)
    GPIO.cleanup()
