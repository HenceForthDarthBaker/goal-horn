import os

def letsgo_tommy():
    
    os.system('sudo pkill mpg321')
    os.system('mpg321 /home/pi/goalhorn/tommyletsgohawks.mp3')