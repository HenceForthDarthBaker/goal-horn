import RPi.GPIO as GPIO, time, os, subprocess

def cubs_light1():
    GPIO.setmode (GPIO.BOARD)
    GPIO.setup(7,GPIO.IN)
    subprocess.Popen(["python", '/home/pi/goalhorn/cubs_run_score.py'])
    time.sleep(.5)
    GPIO.setup(7,GPIO.OUT)
    time.sleep(35)
    GPIO.setup(7,GPIO.IN)
    time.sleep(1)
    GPIO.cleanup()
