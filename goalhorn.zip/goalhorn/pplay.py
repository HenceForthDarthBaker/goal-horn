import os

def hawks_pp():
    
    os.system('sudo pkill mpg321')
    os.system('mpg321 /home/pi/goalhorn/pplay.mp3')