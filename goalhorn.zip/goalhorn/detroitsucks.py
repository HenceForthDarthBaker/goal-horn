import os

def detroit_sucks():
    
    os.system('sudo pkill mpg321')
    os.system('mpg321 /home/pi/goalhorn/detroitsucks.mp3')