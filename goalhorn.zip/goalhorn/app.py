import os
from flask import Flask, render_template,jsonify
from goal_light import flash_lights
from bearlight import bear_light
from cubslight1 import cubs_light1
from cubslight2 import cubs_light2
from go_cubs_go import cubs_win
from bearraid import bear_raid
from pplay import hawks_pp
from tommyletsgohawks import letsgo_tommy
from detroitsucks import detroit_sucks
from stopall import stop_all

app = Flask(__name__)

@app.route('/')
def index():
   return render_template('index.html')
   
@app.route('/goallight')
def goallight():
    flash_lights()
    
    return jsonify('this works')

@app.route('/bearscore')
def bearscore():
    bear_light()
    
@app.route('/cubsrunscore')
def cubsrunscore():
    cubs_light1()
    
@app.route('/cubsrunscore2')
def cubsrunscore2():
    cubs_light2()

@app.route('/gocubsgo')
def gocubsgo():
    cubs_win()
    
@app.route('/bearraid')
def bearraid():
    bear_raid()
    
@app.route('/powerplay')
def powerplay():
    hawks_pp()
    
@app.route('/letsgotommy')
def letsgotommy():
    letsgo_tommy()
    
@app.route('/detroitsucks')
def detroitsucks():
    detroit_sucks()

@app.route('/stop_all')
def stop_all():
    stop_all()

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0')
