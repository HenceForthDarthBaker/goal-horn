import RPi.GPIO as GPIO, time, os, subprocess

def cubs_light2():
    GPIO.setmode (GPIO.BOARD)
    GPIO.setup(7,GPIO.IN)
    subprocess.Popen(["python", '/home/pi/goalhorn/cubs_new_score.py'])
    time.sleep(.5)
    GPIO.setup(7,GPIO.OUT)
    time.sleep(45)
    GPIO.setup(7,GPIO.IN)
    time.sleep(1)
    GPIO.cleanup()