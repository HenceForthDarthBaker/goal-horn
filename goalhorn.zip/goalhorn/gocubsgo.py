import os
os.system('sudo pkill mpg321')
os.system('mpg321 /home/pi/goalhorn/gocubsgo.mp3')