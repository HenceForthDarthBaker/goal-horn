import os

os.system('sudo pkill mpg321')
os.system('mpg321 /home/pi/goalhorn/bearraid.mp3')