import RPi.GPIO as GPIO, os
os.system('sudo pkill mpg321')
GPIO.setup(7,GPIO.IN)
GPIO.cleanup()
