import os
os.system('sudo pkill mpg321')
