class Test:
    def class_test(self):
        pass