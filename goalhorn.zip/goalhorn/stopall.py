import RPi.GPIO as GPIO, os, time, subprocess


def stop_all():
    GPIO.setmode (GPIO.BOARD)
    GPIO.setup(7,GPIO.IN)
    time.sleep(1)
    GPIO.cleanup()
    subprocess.Popen(["python", '/home/pi/goalhorn/stophorn.py'])
